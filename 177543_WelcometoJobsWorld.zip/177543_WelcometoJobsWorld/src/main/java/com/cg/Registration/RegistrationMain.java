package com.cg.Registration;

public class RegistrationMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println("Welcome to Job World");
	}

}
