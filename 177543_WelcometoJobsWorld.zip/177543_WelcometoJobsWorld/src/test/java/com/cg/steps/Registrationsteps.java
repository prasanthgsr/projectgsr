package com.cg.steps;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registrationsteps {

	WebDriver driver;

	@Given("user is on the registration Form")
	public void user_is_on_the_registration_Form() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\sel-jars/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/gprasant/Desktop/sets/SET02/SET02/WebPages/RegistrationForm.html");
	}
	
	@Then("check the title of the page")
	public void check_the_title_of_the_page() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Title of page: " + driver.getTitle());
		assertEquals("Welcome to JobsWorld", driver.getTitle());
	}
	
	@Given("fill form data except Userid")
	public void fill_form_data_except_Userid() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("userid")).sendKeys("");
		driver.findElement(By.id("pwd")).sendKeys("eMPLOYEE");
		driver.findElement(By.id("usrname")).sendKeys("PRASAGVR");
		driver.findElement(By.id("addr")).sendKeys("123041");
		new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
		driver.findElement(By.name("zip")).sendKeys("603103");
		driver.findElement(By.name("email")).sendKeys("prasanthgsr@gmail.com");
		driver.findElement(By.name("sex")).click();
		driver.findElement(By.id("desc")).sendKeys("hello world");;
		Thread.sleep(5000);
	}

	@Given("click on submit")
	public void click_on_submit() {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("submit")).click();
	}

	@Then("switch to alert and accept it")
	public void switch_to_alert_and_accept_it() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert = driver.switchTo().alert();
		String expectedMsg = alert.getText();
		Thread.sleep(3000);
		alert.accept();
	}


	@When("user enters the correct details in Registration page")
	public void user_enters_the_correct_details_in_Registration_page() throws Throwable {
		driver.findElement(By.id("usrID")).sendKeys("prasanth");
		driver.findElement(By.id("pwd")).sendKeys("eMPLOYEE");
		driver.findElement(By.id("usrname")).sendKeys("PRASAGVR");
		driver.findElement(By.id("addr")).sendKeys("123041");
		new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
		driver.findElement(By.name("zip")).sendKeys("603103");
		driver.findElement(By.name("email")).sendKeys("prasanthgsr@gmail.com");
		driver.findElement(By.name("sex")).click();
		driver.findElement(By.id("desc")).sendKeys("hello world");;
		Thread.sleep(5000);
	}

	@When("click on the submit button")
	public void click_on_the_submit_button() {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("submit")).click();
	}
	@When("alert message should be displayed")
	public void alert_message_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Alert alert = driver.switchTo().alert();
		String expectedMsg = alert.getText();
		Thread.sleep(3000);
		alert.accept();
		driver.close();
	}
	@Given("fill form data except Password")
	public void fill_form_data_except_Password() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except Name")
	public void fill_form_data_except_Name() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except Address")
	public void fill_form_data_except_Address() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except Country")
	public void fill_form_data_except_Country() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except Zipcode")
	public void fill_form_data_except_Zipcode() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except email")
	public void fill_form_data_except_email() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Given("fill form data except sex")
	public void fill_form_data_except_sex() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}


}
