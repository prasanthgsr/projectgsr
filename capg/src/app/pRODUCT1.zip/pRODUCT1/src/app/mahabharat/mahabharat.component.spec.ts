import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MahabharatComponent } from './mahabharat.component';

describe('MahabharatComponent', () => {
  let component: MahabharatComponent;
  let fixture: ComponentFixture<MahabharatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MahabharatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MahabharatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
