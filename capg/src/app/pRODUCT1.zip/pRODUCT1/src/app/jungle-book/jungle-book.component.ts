import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jungle-book',
  templateUrl: './jungle-book.component.html',
  styleUrls: ['./jungle-book.component.css']
})
export class JungleBookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
