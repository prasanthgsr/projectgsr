import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JungleBookComponent } from './jungle-book.component';

describe('JungleBookComponent', () => {
  let component: JungleBookComponent;
  let fixture: ComponentFixture<JungleBookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JungleBookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JungleBookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
