import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { SachinComponent } from './sachin/sachin.component';
import { MahabharatComponent } from './mahabharat/mahabharat.component';
import { JungleBookComponent } from './jungle-book/jungle-book.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    SachinComponent,
    MahabharatComponent,
    JungleBookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
