export class Product{
    Pid:number;
    Pname:String;
    Price:number;
    imageurl:String;
    Catogory:String;
    model:String;
    quantity:number;
    description:String;
}