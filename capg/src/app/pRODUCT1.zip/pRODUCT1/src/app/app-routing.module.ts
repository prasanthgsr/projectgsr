import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductComponent } from './product/product.component';
import { MahabharatComponent } from './mahabharat/mahabharat.component';
import { JungleBookComponent } from './jungle-book/jungle-book.component';
import { SachinComponent } from './sachin/sachin.component';


const routes: Routes = [
  {path:'',component:ProductComponent},
  {path:'product',component:ProductComponent},
  {path:'mahabharat',component:MahabharatComponent},
  {path:'jungle-book',component:JungleBookComponent},
  {path:'sachin',component:SachinComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
