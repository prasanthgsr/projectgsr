import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sachin',
  templateUrl: './sachin.component.html',
  styleUrls: ['./sachin.component.css']
})
export class SachinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
