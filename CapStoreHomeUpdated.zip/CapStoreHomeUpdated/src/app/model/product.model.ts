export class Product{

    pid:number;
     pname:string;
     price:number;
     imageurl:string;
     catogory:string;
     model:string;
     quantity:number;
     description:string;
     ratings:number;
     discount:number;
     date:string;
     promocode:String;
     mid:number;
     }