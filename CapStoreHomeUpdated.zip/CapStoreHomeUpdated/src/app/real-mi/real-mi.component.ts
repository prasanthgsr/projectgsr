import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-real-mi',
  templateUrl: './real-mi.component.html',
  styleUrls: ['./real-mi.component.css']
})
export class RealMiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
