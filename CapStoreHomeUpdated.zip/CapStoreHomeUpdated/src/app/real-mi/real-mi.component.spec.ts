import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RealMiComponent } from './real-mi.component';

describe('RealMiComponent', () => {
  let component: RealMiComponent;
  let fixture: ComponentFixture<RealMiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RealMiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RealMiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
