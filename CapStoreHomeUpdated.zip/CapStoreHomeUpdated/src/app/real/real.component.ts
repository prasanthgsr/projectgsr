import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product.model';
@Component({
  selector: 'app-real',
  templateUrl: './real.component.html',
  styleUrls: ['./real.component.css']
})
export class RealComponent implements OnInit {
  products: Product;
  product: Product[];
  constructor(private router:Router, private productService:ProductService) { }

  ngOnInit() {
    this.productService.getUserById(99)
    .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
     //this.products = this.products.filter(u=> u!==product); 
     this.products=data
       });

       this.productService.getProductBymobiles("Mobiles")
       .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
        //this.products = this.products.filter(u=> u!==product); 
        this.product=data
          });
  }

}
