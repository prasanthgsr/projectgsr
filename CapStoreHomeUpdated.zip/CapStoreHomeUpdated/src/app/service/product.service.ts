import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product.model';
import { MobilesComponent } from '../mobiles/mobiles.component';
@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:5003/product';
  //get users
  getProducts()
  {
    return this.http.get<Product[]>(this.baseUrl);
  }
  //http://localhost:5003/product/mobiles?category=Mobiles
  //get users by id
  getProductBymobiles(mob:string){
    return this.http.get<Product[]>(this.baseUrl+'/mobiles?category='+mob);
  }

  //Create User
  getProductByfiction(fic:string){
    return this.http.get<Product[]>(this.baseUrl+'/fic?book='+fic);
  }
  //Create User
  getProductByHistory(cat:string){
    return this.http.get<Product[]>(this.baseUrl+'/cat?book='+cat);
  }

  getProductById(id:number){
    return this.http.get<Product>(this.baseUrl+"/"+id);
  }

   //get user by id
   getUserById(id:number){
    return this.http.get<Product>(this.baseUrl+'/find?id='+id);
  }

 
}
