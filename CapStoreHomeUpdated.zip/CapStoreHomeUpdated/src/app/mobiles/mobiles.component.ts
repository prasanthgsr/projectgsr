import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product.model';
@Component({
  selector: 'app-mobiles',
  templateUrl: './mobiles.component.html',
  styleUrls: ['./mobiles.component.css']
})
export class MobilesComponent implements OnInit {

 //creating an array of User class
 products: Product[];

 

 //Constructor Dependency
 constructor(private router:Router, private productService:ProductService) { }

 //loading all users as soon as component is loaded
 ngOnInit() {
   //if(localStorage.getItem("productname")!=null)
 

   this.productService.getProductBymobiles("Mobiles")
   .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
    //this.products = this.products.filter(u=> u!==product); 
    this.products=data
      });

// else{
//   this.router.navigate(['/list-product']);
//  }
}

calling(product:Product){
  localStorage.setItem("prodId",product.pid.toString());
  if(product.pid==59)
    this.router.navigate(['/real']);
  else if(product.pid==99)
    this.router.navigate(['/real-mi']);
}
 
}
