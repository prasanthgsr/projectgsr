import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CapstoreHomeComponent } from './capstore-home/capstore-home.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { BooksComponent } from './books/books.component';
import { TvComponent } from './tv/tv.component';
import { FictionComponent } from './fiction/fiction.component';
import { HistoryComponent } from './history/history.component';
import { SachinComponent } from './sachin/sachin.component';
import { ProductComponent } from './product/product.component';
import { JungleBookComponent } from './jungle-book/jungle-book.component';
import { MahabharatComponent } from './mahabharat/mahabharat.component';
import { RealComponent } from './real/real.component';
import { RealMiComponent } from './real-mi/real-mi.component';


const routes: Routes = [
  { path: 'home', component: CapstoreHomeComponent },
  { path: 'electronics', component: ElectronicsComponent },
  { path: 'mobiles', component: MobilesComponent },
  { path: 'books', component: BooksComponent },
  { path: 'tv', component: TvComponent },
  { path: 'fiction', component: FictionComponent },
  { path: 'history', component: HistoryComponent },
  { path: 'real', component: RealComponent },
  { path: 'real-mi', component: RealMiComponent },
  { path: 'sachin', component: SachinComponent },
  {path:'product',component:ProductComponent},
  {path:'jungle-book',component:JungleBookComponent},
  {path:'mahabharat',component:MahabharatComponent},
  // { path: 'edit-user', component: EditUserComponent },
  // routerParams
  { path: '', component: CapstoreHomeComponent },
  // Or
  // {path:'',redirectTo:'/home',pathMatch:'full'},
  { path: '**', component: CapstoreHomeComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
