import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capstore-home',
  templateUrl: './capstore-home.component.html',
  styleUrls: ['./capstore-home.component.css']
})
export class CapstoreHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
