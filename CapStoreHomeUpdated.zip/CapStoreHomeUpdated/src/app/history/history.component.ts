import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product.model';
@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {
  products: Product[];
  constructor(private router:Router, private productService:ProductService) { }

  ngOnInit() {
    this.productService.getProductByHistory("History")
   .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
    //this.products = this.products.filter(u=> u!==product); 
    this.products=data
      });

  }
  calling(product:Product){
    localStorage.setItem("prodId",product.pid.toString());
    if(product.pid==95)
      this.router.navigate(['/mahabharat']);
    else if(product.pid==96)
      this.router.navigate(['/sachin']);
  }

}
