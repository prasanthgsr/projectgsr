import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product.model';
@Component({
  selector: 'app-tv',
  templateUrl: './tv.component.html',
  styleUrls: ['./tv.component.css']
})
export class TvComponent implements OnInit {
  products: Product[];
  constructor(private router:Router, private productService:ProductService) { }

  ngOnInit() {
    this.productService.getProductBymobiles("TV")
    .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
     //this.products = this.products.filter(u=> u!==product); 
     this.products=data
       });

      //  calling(this.product:Product){
      //   localStorage.setItem("prodId",product.pid.toString());
      //   if(product.pid==59)
      //     this.router.navigate(['/king']);
      //   else if(product.pid==99)
      //     this.router.navigate(['/rani']);
      // }
  }
  
       calling(product:Product){
        localStorage.setItem("prodId",product.pid.toString());
        if(product.pid==89)
          this.router.navigate(['/product']);
        else if(product.pid==90)
          this.router.navigate(['/sachin']);
      }

}
