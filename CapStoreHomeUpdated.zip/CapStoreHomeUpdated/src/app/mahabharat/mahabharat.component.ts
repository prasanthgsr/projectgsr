import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mahabharat',
  templateUrl: './mahabharat.component.html',
  styleUrls: ['./mahabharat.component.css']
})
export class MahabharatComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
