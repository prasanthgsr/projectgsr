import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CapstoreHomeComponent } from './capstore-home/capstore-home.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { BooksComponent } from './books/books.component';
import { TvComponent } from './tv/tv.component';
import { FictionComponent } from './fiction/fiction.component';
import { HistoryComponent } from './history/history.component';
//import { HttpClientModule } from '../../node_modules/@angular/common/http';
 import { HttpClientModule } from '@angular/common/http';
import { ProductComponent } from './product/product.component';
import { SachinComponent } from './sachin/sachin.component';
import { MahabharatComponent } from './mahabharat/mahabharat.component';
import { JungleBookComponent } from './jungle-book/jungle-book.component';
import { RealComponent } from './real/real.component';
import { RealMiComponent } from './real-mi/real-mi.component';

@NgModule({
  declarations: [
    AppComponent,
    CapstoreHomeComponent,
    MobilesComponent,
    ElectronicsComponent,
    BooksComponent,
    TvComponent,
    FictionComponent,
    HistoryComponent,
    ProductComponent,
    SachinComponent,
    MahabharatComponent,
    JungleBookComponent,
    RealComponent,
    RealMiComponent
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
