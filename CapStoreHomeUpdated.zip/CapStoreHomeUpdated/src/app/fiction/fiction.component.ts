import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../service/product.service';
import { Product } from '../model/product.model';
@Component({
  selector: 'app-fiction',
  templateUrl: './fiction.component.html',
  styleUrls: ['./fiction.component.css']
})
export class FictionComponent implements OnInit {
  products: Product[];
  constructor(private router:Router, private productService:ProductService) { }

  ngOnInit() {
    this.productService.getProductByfiction("Fiction")
   .subscribe(data=>{      //subscribe method observes all the changes and update teh changes
    //this.products = this.products.filter(u=> u!==product); 
    this.products=data
      });

  }
  calling(product:Product){
    localStorage.setItem("prodId",product.pid.toString());
    if(product.pid==91)
      this.router.navigate(['/jungle-book']);
    else if(product.pid==92)
      this.router.navigate(['/product']);
  }

}
