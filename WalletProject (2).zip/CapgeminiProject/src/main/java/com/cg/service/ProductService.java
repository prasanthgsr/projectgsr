package com.cg.service;
import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cg.entities.Product;

public interface ProductService 
{
	 void create(Product ac);
//	 Product findById(Integer pid);
	 //void transferAccount(double amount, Product a1,Product a2);
	 //void addMoney(double amount, Product ac);
	 List<Product> findAll();
	 //void deleteByID(Integer productid);
//	 Product isAvailability(Product pid,Product ac);
//	 void afterbuyingByID(Integer pid);
	 //void withdraw(Double amount,Product ac);
	 //Product showBalance(Integer id);
	 List<Product> searchbymobile(String catogory);
	 List<Product> searchbytv(String catogory);
	 List<Product> searchbyFiction(String catogory);
	 List<Product> searchbyhistory(String catogory);
	
	
}
