package com.cg.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.ProductDao;
import com.cg.entities.Product;
import com.cg.exception.ApplicationException;





@Service
@Transactional
public class ProductServiceImpl implements ProductService {

	@Autowired private ProductDao dao;	
	
	@Transactional
	public void create(Product ac) {
		// TODO Auto-generated method stub
		dao.save(ac);
	}

	

	
	
	
	@Transactional
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}


	




	@Transactional
	public List<Product> searchbymobile(String productcategory) {
		// TODO Auto-generated method stub
		
		return dao.searchbymobile(productcategory);
	}


	@Transactional
	public List<Product> searchbytv(String productcategory) {
		// TODO Auto-generated method stub
		return dao.searchbytv(productcategory);
	}


	@Transactional
	public List<Product> searchbyFiction(String catogory) {
		// TODO Auto-generated method stub
		return dao.searchbyFictionbook(catogory);
	}


	@Transactional
	public List<Product> searchbyhistory(String catogory) {
		// TODO Auto-generated method stub
		return dao.searchbyhistory(catogory);
	}



	
}
	 

	



	


	


