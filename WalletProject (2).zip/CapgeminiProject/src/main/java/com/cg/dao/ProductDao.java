package com.cg.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.entities.Product;


@Repository
public interface ProductDao extends JpaRepository<Product, Integer>
{

	@Query("select p from Product p where p.catogory=:mobiles")
	public List<Product> searchbymobile(@Param("mobiles") String productcategory);

	@Query("select p from Product p where p.catogory=:tv")
	public List<Product> searchbytv(@Param("tv") String productcategory);

	@Query("select p from Product p where p.catogory=:book")
	public List<Product> searchbyFictionbook(@Param("book") String productcategory);
	
	@Query("select p from Product p where p.catogory=:book")
	public List<Product> searchbyhistory(@Param("book") String productcategory);

	
	
}
