package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.entities.Employee;

public interface IEmployeeService {
	void create(Employee empl);
	void update(Employee empl);
	void delete(String empid);
	List<Employee> viewEmployee();
    Employee find(String empid);
    String getSalary(String empid);
    String getDeptname(String empid);
}
