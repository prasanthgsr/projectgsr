package com.cg.employeemanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employeemanagement.entities.Employee;
import com.cg.employeemanagement.services.EmployeeServiceImpl;

@RestController
//to use only data and dont print model view and to indicate this class as this way
public class EmployeeController {

	//to use dao object for all methods without declaring everytime using autowired annotation
	@Autowired
	private EmployeeServiceImpl service;

	// test url:http://localhost:8087/create
	//to create details in  database using post mapping
	@PostMapping(value = "/create", consumes = { "application/json" })
	public ResponseEntity<String> create(@RequestBody Employee empl) {
		service.create(empl);
		;
		// Return Response body "Record Created" with response status=201
		return new ResponseEntity<String>("Employee Created successfully", HttpStatus.CREATED);
	}

	// test url:http://localhost:8087delete/1230414123
	//to delete details from  database using deletemapping
	@DeleteMapping(value = "/delete/{empid}")
	public ResponseEntity<String> delete(@PathVariable String empid) {
		service.delete(empid);
		return new ResponseEntity<String>("Employee deleted successfully", HttpStatus.OK);
	}

	// test url:http://localhost:8087/employees
	//to get details from  postman using getmapping
	@GetMapping(value = "/employees")
	public List<Employee> getAllEmployee() {
		return service.viewEmployee();
	}

	// test url:http://localhost:8087/accounts/update/
	//to put details in  postman using putmapping
	@PutMapping(value = "/updateemployee", consumes = { "application/json" })
	public ResponseEntity<String> update(@RequestBody Employee empl) {
		service.update(empl);
		// Return Response body "Record Created" with response status=201
		return new ResponseEntity<String>("Employee updated successfully\n" + empl.toString(), HttpStatus.OK);
	}

	// test url:http://localhost:8087/getbyid
	//to get details from  postman using getmapping
	@GetMapping(value = "/getbyid", produces = { "application/json" })
	public Employee find(@RequestParam String empid) {
		return service.find(empid);
	}

	// http://localhost:8087/getsalary
	//to get details from  postman using getmapping
	@GetMapping(value = "/getsalary/{empid}")
	public Double getsalary(@PathVariable String empid) {
		Employee sal = service.find(empid);
		Double salary = sal.getSalary();
		return salary;
	}
	
	// http://localhost:8087/getdepartment
	//to get details from  postman using getmapping
	@GetMapping(value = "/getdepartment/{empid}")
	public String getdepartment(@PathVariable String empid) {
			Employee dept = service.find(empid);
		    String department =dept.getDeptName();
			return department;
		}
	
	// http://localhost:8087/getdesignation
	//to get details from  postman using getmapping
		@GetMapping(value = "/getdesignation/{empid}")
		public String getdesignatiion(@PathVariable String empid) {
				Employee design = service.find(empid);
			    String designation =design.getDesignation();
				return designation;
			}

}
