package com.cg.employeemanagement.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemanagement.dao.IEmployeeDao;
import com.cg.employeemanagement.entities.Employee;
import com.cg.employeemanagement.exception.ApplicationException;

@Service
//to indicate this class as service
public class EmployeeServiceImpl implements IEmployeeService {

	//to use dao object for all methods without declaring everytime using autowired annotation
	@Autowired
	private IEmployeeDao dao;

	@Transactional
	public void create(Employee empl) {
		// TODO Auto-generated method stub
		dao.save(empl);

	}

	@Transactional
	public void update(Employee empl) {
		// TODO Auto-generated method stub
		dao.save(empl);

	}

	@Transactional
	public void delete(String empid) {
		// TODO Auto-generated method stub
		Optional<Employee> record = dao.findById(empid);
		if (!record.isPresent()) {
			throw new ApplicationException(
					"Employee id not found in registry" + "\nPlease check the employee id you entered");
		} else {
			dao.deleteById(empid);
		}

	}

	@Transactional
	public List<Employee> viewEmployee() {
		// TODO Auto-generated method stub

		return dao.findAll();
	}

	@Transactional
	public Employee find(String empid) {
		// TODO Auto-generated method stub
		Optional<Employee> record = dao.findById(empid);
		if (!record.isPresent()) {
			throw new ApplicationException(
					"Employee not found in registry!\n " + "Please enter the corect employee id");
		} else {
			return dao.findById(empid).get();
		}
	}

	@Transactional
	public String getSalary(String empid) {
		// TODO Auto-generated method stub
		String s = "displaying the salary";
		Employee record = find(empid);
		Double salary = record.getSalary();
		return s;
	}

	@Transactional
	public String getDeptname(String empid) {
		// TODO Auto-generated method stub
		String s = "Department is displayed";
		Employee record = find(empid);
		String department = record.getDeptName();
		return null;
	}

}
