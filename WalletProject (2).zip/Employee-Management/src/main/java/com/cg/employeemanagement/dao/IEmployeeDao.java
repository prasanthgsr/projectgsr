package com.cg.employeemanagement.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.employeemanagement.entities.*;
@Repository
//to indicate this interface as repository which has predefined functions
public interface IEmployeeDao extends JpaRepository<Employee, String> {

	
}



