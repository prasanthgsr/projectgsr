package com.cg.employeemanagement.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;


//creating model class for the data to be entered
@Entity // to indicate to map this class to table
@Table(name = "Employee") //declaring table name
@XmlRootElement
public class Employee implements Serializable {

	@Id
	@Column(name = "empid", length = 20)
	private String empid;
	@Column(name = "name", length = 30)
	private String name;
	@Column(name = "designation", length = 40)
	private String designation;
	@Column(name = "salary", length = 20)
	private Double salary;
	@Column(name = "deptname", length = 30)
	private String deptName;

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
     //to print details of employee
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", designation=" + designation + ", salary=" + salary
				+ ", deptName=" + deptName + "]";
	}

}
