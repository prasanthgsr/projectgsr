import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CapstoreHomeComponent } from './capstore-home/capstore-home.component';

const routes: Routes = [
  {path:'',component:CapstoreHomeComponent},
  {path:'home',component:CapstoreHomeComponent},
  {path:'',component:CapstoreHomeComponent},
  {path:'**',component:CapstoreHomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  
  exports: [RouterModule]
})
export class AppRoutingModule { }
