package com.test;

import static org.junit.Assert.*;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {

	
	WebDriver driver = null;
	
	PageModel model=null;
		
	@Given("User is on Registration Page")
	public void user_is_on_Registration_Page() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SELINEUMJARS\\chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("file:///C:/Users/nagthota/Desktop/M4/SET02/SET02/WebPages/RegistrationForm.html");
		model = new PageModel(driver);
		
	}

	@Then("verify the title name")
	public void verify_the_title_name() {
		System.out.println("Title on Page : "+driver.getTitle());
		driver.close();
	}

	@When("user enters invalid UserId")
	public void user_enters_invalid_UserId() throws Throwable {
	   
		model.getUserid().sendKeys("");//try sending EMPTY username
		 model.triggerClick();
		 Thread.sleep(1000);
		 
		
	}

	@Then("display alert box message for invalid UserId")
	public void display_alert_box_message_for_invalid_UserId() throws Throwable {
	    String Expectedmessage="User Id should not be empty / length be between 5 to 12";
	    String ActualMessage=driver.switchTo().alert().getText();
	    
	   
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    
	    
	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
	}

	@When("user enters invalid password")
	public void user_enters_invalid_password() throws Throwable {
		
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("");
		 model.triggerClick();
		    Thread.sleep(1000);
	}

	@Then("display alert box message for invalid password")
	public void display_alert_box_message_for_invalid_password() throws InterruptedException {

		 String Expectedmessage="Password should not be empty / length be between 7 to 12";
		    String ActualMessage=driver.switchTo().alert().getText();
		    
		    Thread.sleep(2000);
		    assertEquals(Expectedmessage, ActualMessage);
		    driver.switchTo().alert().accept();
		    
		    
		    System.out.println("Expected message : "+Expectedmessage);
		    System.out.println("ActualMessage : "+ActualMessage);
		    driver.close();
	
	
	}

	@When("user enters invalid Name")
	public void user_enters_invalid_Name() throws Throwable {
	    
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("");
		 model.triggerClick();
		  Thread.sleep(1000);
	}

	@Then("display alert box message for invalid Name")
	public void display_alert_box_message_for_invalid_Name() throws Throwable {
		
		String Expectedmessage="Name should not be empty and must have alphabet characters only";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    
	  
	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();

	}

	@When("user enters invalid Address")
	public void user_enters_invalid_Address() throws Throwable {
	   
		
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("");
		 model.triggerClick();
		    Thread.sleep(1000);
	}

	@Then("display alert box message for invalid Address")
	public void display_alert_box_message_for_invalid_Address() throws Throwable {
	  
		String Expectedmessage="User address must have alphanumeric characters only";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    

	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
		
		
	}

	@When("user choose invalid selection Country")
	public void user_choose_invalid_selection_Country() throws Throwable {
	   
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("Chennai");
	    new Select(driver.findElement(By.name("country"))).selectByVisibleText("(Please select a country)");
	    
		 model.triggerClick();
		    Thread.sleep(1000);
		
	}

	@Then("display alert box message for Country")
	public void display_alert_box_message_for_Country() {
		String Expectedmessage="Select your country from the list";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    

	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
	}

	@When("user enters invalid Zipcode")
	public void user_enters_invalid_Zipcode() throws Throwable {
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("Chennai");
	    new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
	    model.getZip().sendKeys("");
		 model.triggerClick();
		    Thread.sleep(1000);
	}

	@Then("display alert box message for Zipcode")
	public void display_alert_box_message_for_Zipcode() {
		String Expectedmessage="ZIP code must have numeric characters only";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    

	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
	}

	@When("user enters invalid emaiId")
	public void user_enters_invalid_emaiId() throws Throwable {
	  
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("Chennai");
	    new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
	    model.getZip().sendKeys("603103");
	    model.getEmail().sendKeys("");
	    model.triggerClick();
	    Thread.sleep(1000);
		
	}

	@Then("display alert box message for emaiId")
	public void display_alert_box_message_for_emaiId() {
	
		String Expectedmessage="You have entered an invalid email address!";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    

	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
		
	}

	@When("user choose invalid selection Gender")
	public void user_choose_invalid_selection_Gender() throws Throwable {
	
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("Chennai");
	    new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
	    model.getZip().sendKeys("603103");
	    model.getEmail().sendKeys("capgemini@gmail.com");

	    model.triggerClick();
	    Thread.sleep(3000);
		
	}

	@Then("display alert box message for Gender")
	public void display_alert_box_message_for_Gender() {
		
		String Expectedmessage="Please Select gender";
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    assertEquals(Expectedmessage, ActualMessage);
	    driver.switchTo().alert().accept();
	    

	    System.out.println("Expected message : "+Expectedmessage);
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
	}


	
	@When("user choose default selection of Language")
	public void user_choose_default_selection_of_Language() throws Throwable {
	  
		model.getUserid().sendKeys("Nagavenu");
	    model.getPassid().sendKeys("nagavenu");
	    model.getUsername().sendKeys("nagthota");
	    model.getAddress().sendKeys("Chennai");
	    new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
	    model.getZip().sendKeys("603103");
	    model.getEmail().sendKeys("capgemini@gmail.com");
	    driver.findElement(By.name("sex")).click();
	    driver.findElement(By.name("en")).isSelected();
	    model.getAbout().sendKeys("Professional");
	   
	    
		
	}

	@Then("click on Submit")
	public void click_on_Submit() throws Throwable {
	   
		 model.triggerClick();
		    Thread.sleep(3000);
		String ActualMessage=driver.switchTo().alert().getText();
	    
	    
	    driver.switchTo().alert().accept();
	    

	
	    System.out.println("ActualMessage : "+ActualMessage);
	    driver.close();
	}


	
	}