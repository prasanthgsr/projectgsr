package com.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageModel {

	private WebDriver dr=null;
	
	public PageModel(WebDriver driver) {

		super();
		this.dr=driver;
		
		//Register the Page Factory : Responsible to extract all web elements 
		PageFactory.initElements(driver, this);
	
	}
	
	@FindBy(name="userid")
	private WebElement userid;
	
	@FindBy(name="passid")
	private WebElement passid;
	
	@FindBy(name="username")
	private WebElement username;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="country")
	private WebElement country;
	
	@FindBy(name="zip")
	private WebElement zip;
	
	@FindBy(name="email")
	private WebElement email;
	
	@FindBy(id="gender")
	private WebElement gender;
	
	@FindBy(name="en")
	private WebElement en;
	
	@FindBy(name="desc")
	private WebElement about;
	
	@FindBy(name="submit")
	private WebElement submit;

	

	public WebElement getUserid() {
		return userid;
	}

	public void setUserid(WebElement userid) {
		this.userid = userid;
	}

	public WebElement getPassid() {
		return passid;
	}

	public void setPassid(WebElement passid) {
		this.passid = passid;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(WebElement username) {
		this.username = username;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(WebElement address) {
		this.address = address;
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(WebElement country) {
		this.country = country;
	}

	public WebElement getZip() {
		return zip;
	}

	public void setZip(WebElement zip) {
		this.zip = zip;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(WebElement gender) {
		this.gender = gender;
	}

	public WebElement getEn() {
		return en;
	}

	public void setEn(WebElement en) {
		this.en = en;
		
		
	}
	public WebElement getAbout() {
		return about;
	}

	public void setAbout(WebElement about) {
		this.about = about;
	}

	public void triggerClick() {
		System.out.println("Click on Submit");
		submit.click();
	}
	
	
	
}
